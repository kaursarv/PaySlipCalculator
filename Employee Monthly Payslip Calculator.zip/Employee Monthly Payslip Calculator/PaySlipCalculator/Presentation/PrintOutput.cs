﻿using PaySlipCalculator.Model;
using System;

namespace PaySlipCalculator.Presentation
{
    //Class to print output
    class PrintOutput : IPrintOutput
    {
        //Prints output on the console
        public void PrintPayslip(EmployeeModel employee)
        {
            Console.WriteLine("\r\n" + "Monthly Payslip for: " + "\"" +  employee.EmployeeName + "\"");
            Console.WriteLine("Gross Monthly Income: $" + employee.MonthlyPaySlip.GrossMonthlyIncome);
            Console.WriteLine("Monthly Income Tax: $" + employee.MonthlyPaySlip.MonthlyIncomeTax);
            Console.WriteLine("Net Monthly Income: $" + employee.MonthlyPaySlip.NetMonthlyIncome);
            Console.WriteLine("\r\n" + "Press any key to exit..");
            Console.ReadKey();
        }
    }
}
