﻿using PaySlipCalculator.Model;
using System;


namespace PaySlipCalculator.Presentation
{
    class UserInput : IUserInput
    {
        public string input;
        public TaskTypes task;
        string[] splitInput;

        //Ask for input from user.
        public TaskTypes PromptUserInput()
        {
            try
            {
                Console.WriteLine("Please enter Input.. " + "\r\n" + "Use format : GenerateMonthlyPayslip \"Name\" Salary" + "\r\n" +
                    "For example -  GenerateMonthlyPayslip \"TestUser\" 60000");

                input = Console.ReadLine();
                splitInput = input.Split("\"");
                if (!string.IsNullOrEmpty(input))
                {
                    task = (TaskTypes)Enum.Parse(typeof(TaskTypes), splitInput[0], true);
                }

                return task;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return TaskTypes.None;
        }

        //Fill Employee model with user input data
        public EmployeeModel PrefillUserInputToEmployeeModel()
        {
            EmployeeModel employee = new EmployeeModel();
            try
            {
                if (splitInput.Length == 3 && !string.IsNullOrEmpty(input))
                {
                    employee.task = task;
                    employee.EmployeeName = splitInput[1];
                    employee.AnnualSalary = decimal.Parse(splitInput[2]);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            return employee;
        }

        // Perform basic validations on user input.
        // Future Tasks - create a seperate class. 
        public bool ValidateInputParameters(EmployeeModel employee)
        {
            try
            {
                if (!input.Contains("\""))
                {
                    Console.WriteLine("Please provide correct input");
                    return false;

                }

                if (employee.task != TaskTypes.GenerateMonthlyPayslip)
                {
                    Console.WriteLine("Please provide task type " +
                                      "'GenerateMonthlyPayslip' to see monthly payslip.");
                    return false;
                }

                if (string.IsNullOrEmpty(employee.EmployeeName))
                {
                    Console.WriteLine("Employee Name cannot be null.");
                    return false;
                }

                if (employee.AnnualSalary <= 0)
                {
                    Console.WriteLine("Annual Salary can't be less than 0.");
                    return false;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error: Invalid Parameters " +
                                  "\r\n" + "Please enter valid parameters only." +
                                  " For Usage please see below : " + "\r\n");
                return false;
            }

            return true;
        }
    }
}
