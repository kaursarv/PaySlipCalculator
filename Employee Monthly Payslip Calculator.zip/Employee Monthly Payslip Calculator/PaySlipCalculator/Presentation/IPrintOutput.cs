﻿using PaySlipCalculator.Model;


namespace PaySlipCalculator.Presentation
{
    interface IPrintOutput
    {
        void PrintPayslip(EmployeeModel employee);
    }
}
