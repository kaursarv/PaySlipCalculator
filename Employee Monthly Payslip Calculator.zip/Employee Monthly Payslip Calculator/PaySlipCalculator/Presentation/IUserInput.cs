﻿
using PaySlipCalculator.Model;

namespace PaySlipCalculator.Presentation
{
    public interface IUserInput
    {
        //Method to generate Monthly pay slip values
        public EmployeeModel PrefillUserInputToEmployeeModel();
    }
}
