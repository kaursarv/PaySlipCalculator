﻿using PaySlipCalculator.Model;

namespace PaySlipCalculator.Business
{
    // Interface for SalaryCalculator 
    public interface ISalaryCalculator
    {
       
        public decimal GetGrossMonthlyIncome();
        public decimal GetMonthlyIncomeTax();
        public decimal GetNetMonthlyIncome();
        public MonthlyPaySlipModel GenerateMonthlyPayslipValues(decimal annualSalary);
    }
}
