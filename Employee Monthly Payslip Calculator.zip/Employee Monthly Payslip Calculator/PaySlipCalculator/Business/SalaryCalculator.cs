﻿using PaySlipCalculator.Model;
using System;


namespace PaySlipCalculator.Business
{
    public class SalaryCalculator : ISalaryCalculator
    {
        #region Properties
       public decimal annualSalary,
                      grossMonthlyIncome,
                      monthlyIncomeTax = 0,
                      netMonthlyIncome;
        #endregion
        
        #region Methods
        //method to Test calculate Monthly income before tax
        public decimal GetGrossMonthlyIncome()
        {
            grossMonthlyIncome = Math.Round(annualSalary / 12);
            return grossMonthlyIncome;
        }
        // Test calculate monthly income tax
        public decimal GetMonthlyIncomeTax()
        {
            monthlyIncomeTax = Math.Round(CalculateAnnualIncomeTax() / 12);

            return monthlyIncomeTax;
        }
        public decimal CalculateAnnualIncomeTax()
        {
            try
            {
                var taxBands = new[]
                {
                    new {Lower = 0m, Upper = 20000m, Rate = 0.0m},
                    new {Lower = 20001m, Upper = 40000m, Rate = 0.1m},
                    new {Lower = 40001m, Upper = 80000m, Rate = 0.2m},
                    new {Lower = 80001m, Upper = 180000m, Rate = 0.3m},
                    new {Lower = 180001m, Upper = decimal.MaxValue, Rate = 0.4m}
                };

                var annualIncomeTax = 0m;

                foreach (var band in taxBands)
                {
                    if (annualSalary > band.Lower)
                    {
                        var taxableAtThisRate = Math.Min(band.Upper - band.Lower, annualSalary - band.Lower);
                        var taxThisBand = taxableAtThisRate * band.Rate;
                        annualIncomeTax += taxThisBand;
                    }
                }

                return annualIncomeTax;
            }
            catch (Exception)
            {
                Console.WriteLine("An error occured while calculating monthly income tax");
                return 0;

            }
        }
        // Test alculate monthly income after tax
        public decimal GetNetMonthlyIncome()
        {
            netMonthlyIncome = Math.Round(grossMonthlyIncome - monthlyIncomeTax);
            return netMonthlyIncome;
        }
        //Test Generate Monthly Payslip Values
        public MonthlyPaySlipModel GenerateMonthlyPayslipValues(decimal annualSalary)
        {
            this.annualSalary = annualSalary;
            
            MonthlyPaySlipModel monthlyPaySlip = new MonthlyPaySlipModel();
            monthlyPaySlip.GrossMonthlyIncome = GetGrossMonthlyIncome();
            monthlyPaySlip.MonthlyIncomeTax = GetMonthlyIncomeTax();
            monthlyPaySlip.NetMonthlyIncome = GetNetMonthlyIncome();
            return monthlyPaySlip;
        }
    }
    #endregion
}
