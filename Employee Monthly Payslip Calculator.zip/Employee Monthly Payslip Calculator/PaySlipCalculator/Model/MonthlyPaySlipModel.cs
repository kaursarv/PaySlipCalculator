﻿
namespace PaySlipCalculator.Model
{
    //Monthly Pay slip view Model
    public class MonthlyPaySlipModel
    {
        public decimal GrossMonthlyIncome { get; set; }
        public decimal MonthlyIncomeTax { get; set; }
        public decimal NetMonthlyIncome { get; set; }
    }
}
