﻿namespace PaySlipCalculator.Model
{
    //Employee View Model
    public class EmployeeModel
    {
        public string EmployeeName { get; set; }
        public decimal AnnualSalary { get; set; }
        public MonthlyPaySlipModel MonthlyPaySlip { get; set; }
        public TaskTypes task { get; set; }

    }
}
