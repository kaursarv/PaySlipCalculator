﻿namespace PaySlipCalculator.Model
{
    //Tasks type
    public enum TaskTypes
    {
        None,
        GenerateMonthlyPayslip,
    }
}
