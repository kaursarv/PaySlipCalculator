﻿using PaySlipCalculator.Business;
using PaySlipCalculator.Model;
using PaySlipCalculator.Presentation;
using System;

namespace PaySlipCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create Objects
            UserInput userInput = new UserInput();
            SalaryCalculator salaryCalculator = new SalaryCalculator();
            EmployeeModel employee = new EmployeeModel();
            PrintOutput printOutput = new PrintOutput();

            // Ask User Input and extract what kind of task we want to perform
            employee.task = userInput.PromptUserInput();

            //Map user input Name and annual Salary to our EmployeeModel
            employee = userInput.PrefillUserInputToEmployeeModel();

            //Validate Input
            bool isValid = userInput.ValidateInputParameters(employee);

            if (isValid)
            {
                //Run functions related to the task type
                switch (userInput.task)
                {
                    case TaskTypes.GenerateMonthlyPayslip:
                        {
                            //Generate Monthly payslip for Employee
                            employee.MonthlyPaySlip = salaryCalculator.GenerateMonthlyPayslipValues(employee.AnnualSalary);

                            //Print Output 
                            printOutput.PrintPayslip(employee);
                        }
                        break;
                    case TaskTypes.None:
                        {
                            Console.WriteLine("Please Input a valid task..");
                        }
                        break;
                }

            }



        }
    }
}
