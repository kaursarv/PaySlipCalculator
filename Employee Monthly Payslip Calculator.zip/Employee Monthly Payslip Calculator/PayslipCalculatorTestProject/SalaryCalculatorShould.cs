using PaySlipCalculator.Business;
using PaySlipCalculator.Model;
using System;
using Xunit;

namespace SalaryCalculatorTestProject
{
    public class SalaryCalculatorShould
    {
        public readonly SalaryCalculator sut = new SalaryCalculator();

        [Theory]
        [InlineData(20000,1667)]
        [InlineData(40000, 3333)]
        [InlineData(60000, 5000)]
        [InlineData(80000, 6667)]
        [InlineData(180000, 15000)]
        [InlineData(240000, 20000)]
        public void ReturnGrossMonthlyIncome(decimal annualSalary, decimal expectedGrossMonthlyIncome)
        {
            //Arrange
            sut.annualSalary = annualSalary;
            //Act
            decimal actualGrossMonthlyIncome= sut.GetGrossMonthlyIncome();
            //Assert
            Assert.Equal(expectedGrossMonthlyIncome, actualGrossMonthlyIncome);
        }
        [Theory]
        [InlineData(20000, 0)]
        [InlineData(40000,167)]
        [InlineData(60000, 500)]
        [InlineData(180000, 3333)]
        [InlineData(200000, 4000)]
        public void ReturnMonthlyIncomeTax(decimal annualSalary, decimal expectedMonthlyIncomeTax)
        {
            //Arrange
            sut.annualSalary = annualSalary;
            //Act
            decimal actualMonthlyIncomeTax = sut.GetMonthlyIncomeTax();
            //Assert
            Assert.Equal(expectedMonthlyIncomeTax, actualMonthlyIncomeTax);
        }
        [Theory]
        [InlineData(20000, 1667)]
        [InlineData(40000, 3166)]
        [InlineData(60000, 4500)]
        public void ReturnNetMonthlyIncome(decimal annualSalary, decimal expectedNetMonthlyIncome)
        {
            //Arrange
            sut.annualSalary = annualSalary;
            //Act
            sut.GetGrossMonthlyIncome();
            sut.GetMonthlyIncomeTax();
            decimal actualNetMonthlyIncome = Math.Round(sut.GetNetMonthlyIncome());
            //Assert
            Assert.Equal(expectedNetMonthlyIncome, actualNetMonthlyIncome);
        }
        [Fact]
        public void GenerateMonthlyPayslipValues()
        {
            //Arrange
            decimal annualSalary = 60000;
            MonthlyPaySlipModel expectedmonthlyPaySlip = new MonthlyPaySlipModel{
                 GrossMonthlyIncome = 5000,  MonthlyIncomeTax = 500, NetMonthlyIncome = 4500
            };
            //Act
            MonthlyPaySlipModel actualMonthlyPaySlip = sut.GenerateMonthlyPayslipValues(annualSalary);
            //Assert
            Assert.Equal(expectedmonthlyPaySlip.ToString(),actualMonthlyPaySlip.ToString());
        }

    }
}
